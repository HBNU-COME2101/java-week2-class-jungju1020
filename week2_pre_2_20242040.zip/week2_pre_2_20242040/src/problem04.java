import java.util.Scanner;

public class problem04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

		System.out.print("여행지>>");
		String d = scanner.nextLine();
		
		System.out.print("인원수>>");
		int p = scanner.nextInt();
		
		System.out.print("숙박일 >> ");
        int n = scanner.nextInt();
		
		System.out.print("1인당 항공료 >> ");
        int f = scanner.nextInt();

        System.out.print("1방 숙박비 >> ");
        int r = scanner.nextInt();

        scanner.close();

        int rooms = (p + 1) / 2;

        int totalf = p * f;
        int totalr = rooms * r * n;  
        int total = totalf + totalr;  

        System.out.println(p + "명의 " + d + " " + n + "박 " + (n + 1) + "일 여행에는 " +
                rooms + "개 필요하며 경비는 " + total + "원입니다.");
	}

}
