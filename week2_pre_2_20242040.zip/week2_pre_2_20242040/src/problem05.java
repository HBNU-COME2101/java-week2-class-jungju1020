import java.util.Scanner;

public class problem05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("나이를 입력하세요 >> ");
        int a = scanner.nextInt();
        scanner.close();
        
        
        if (a <= 0) {
            System.out.println("나이는 양수로만 입력하세요.");
            return;
        }

        
        int red = a / 10;        
        int blue = (a % 10) / 5; 
        int yellow = a % 5;    

        int total = red + blue + yellow;

        System.out.println("빨간 초 " + red + "개, 파란 초 " + blue + "개, 노란 초 " + yellow + "개. 총 " + total + "개가 필요합니다.");
    }
}
