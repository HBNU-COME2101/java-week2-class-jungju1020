import java.util.Scanner;
	
public class problem03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("생일 입력 하세요 >> ");
        int a = scanner.nextInt();
        scanner.close();
        
        int b = a / 10000;
        int c = ( a % 10000 ) / 100;
        int d = a % 100;
        
        System.out.println( b + "년" + c + "월" + d + "일" );
	}

}
